﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class QuitApplication : MonoBehaviour
{

	public void quit()
    {
		Application.Quit();
	}
}
